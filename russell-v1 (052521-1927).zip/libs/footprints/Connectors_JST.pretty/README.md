# Connectors_JST.pretty
This is a legacy repo for kicad v4. No new pull requests will be accepted here. Replacement repo: https://github.com/KiCad/kicad-footprints

This library contains footprints for JST connectors - www.jst.com

Footprints for the following connectors are available:
* **ACH** - http://www.jst-mfg.com/product/detail_e.php?series=9
* **AUH** - http://www.jst-mfg.com/product/detail_e.php?series=629
* **EH** - http://www.jst-mfg.com/product/detail_e.php?series=58
* **GH** - http://www.jst-mfg.com/product/detail_e.php?series=105
* **JFA J200** - http://www.jst-mfg.com/product/detail_e.php?series=531
* **PH** - http://www.jst-mfg.com/product/detail_e.php?series=199
* **PUD** - http://www.jst-mfg.com/product/detail_e.php?series=471
* **SH** - http://www.jst-mfg.com/product/detail_e.php?series=231
* **SHL** - http://www.jst-mfg.com/product/detail_e.php?series=233
* **SUR** - http://www.jst-mfg.com/product/detail_e.php?series=246
* **XH** - http://www.jst-mfg.com/product/detail_e.php?series=277
* **ZE** - http://www.jst-mfg.com/product/detail_e.php?series=470
